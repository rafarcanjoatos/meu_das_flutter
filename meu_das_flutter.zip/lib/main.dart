import 'package:flutter/material.dart';
import 'package:meu_das_flutter/my_app.dart';

void main() {
  runApp(const MyApp());
}
